//
//  ContentView.swift
//  I Am Rich 2020
//
//  Created by LEON on 01/11/2020.
//  Copyright © 2020 LEON_Lau. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
